complete -c lex-fetch -s c -l config -d 'Path to KDL config file' -r -F
complete -c lex-fetch -l no-codegen -d 'Skip code generation step'
complete -c lex-fetch -s v -l verbose -d 'Verbose output'
complete -c lex-fetch -s h -l help -d 'Print help'
complete -c lex-fetch -s V -l version -d 'Print version'
