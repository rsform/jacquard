complete -c jacquard-codegen -s i -l input -d 'Directory containing Lexicon JSON files' -r -F
complete -c jacquard-codegen -s o -l output -d 'Output directory for generated Rust code' -r -F
complete -c jacquard-codegen -s h -l help -d 'Print help'
complete -c jacquard-codegen -s V -l version -d 'Print version'
